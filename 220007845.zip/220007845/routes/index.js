var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {page:'Home', menuId:'home'});
});

router.get('/home', function(req, res, next) {
  res.render('home', {page:'Home', menuId:'home'});
});

router.get('/student', function(req, res, next) {
  res.render('student', {page:'Student', menuId:'student'});
});

module.exports = router;
