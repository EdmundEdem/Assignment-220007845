var express = require('express');
var app = express();

var student_list = [
    {
        Name: 'Billy Bones',
        DateOfBirth: '2000-02-28',
        Program: 'ICT',
        Level: 200,
        Image: 'bbones.jpg'
    },
    {
        Name: 'Alex Andra',
        DateOfBirth: '1977-09-02',
        Program: 'Sociology',
        Level: 100,
        Image: 'wow.jpg'
    },

];

function menu() {
    return  `
    <a href="/">Home</a> |
    <a href="/students">Students</a>
    <br>
    `
}

app.get('/', function (req, res) {
    page = menu() + "Welcome!";
    res.send(page);
});

app.get('/students/', function (req, res) {
    page = menu() + "<h1>Student List</h1>";
    student_list.forEach(function(item, index) {
        page += index + ". ";
        page += '<a href="/student/' + index + '">' + item.Name + '</a><br>';
    });
    res.send(page);
});

app.get('/student/:id', function (req, res) {
    page = menu() + "<h1>Student details</h1>";
    var student = student_list[req.params.id];
    for (key in student) {
        page += "<b>" + key + "</b>:" + student[key] + "<br>";
    }
    res.send(page);

});

var server = app.listen(8000, function () {
    var host = server.address().address
    var port = server.address().port
})

/*
var express = require('express');
var path = require('path');
var logger = require('morgan');
var index = require('./routes/index');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// set path for static assets
app.use(express.static(path.join(__dirname, 'public')));


// routes
app.use('/', index);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // render the error page
  res.status(err.status || 500);
  res.render('error', {status:err.status, message:err.message});
});

module.exports = app;
*/
