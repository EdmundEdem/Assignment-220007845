# Assignment Instruction


* run node app.js in the terminal

* then go to the browser and open http://localhost:8000


